# GetNetworkStatus.ps1
# Called by the Rainmeter skin (via the RunCommand plugin) on a timer.
# Writes a simple KEY=VALUE text file that Rainmeter's WebParser plugin reads.
#
# Usage: powershell -NoProfile -ExecutionPolicy Bypass -File GetNetworkStatus.ps1 "<output file path>"
#
# NOTE: This deliberately avoids the NetTCPIP module (Get-NetIPAddress /
# Get-NetTCPConnection). Those are CIM/WMI-backed cmdlets whose behavior
# under pwsh (PowerShell 7.x) has been inconsistent across releases -
# some builds return nothing at all with no error. Everything here uses
# either plain .NET BCL calls or netstat, both of which behave identically
# across Windows PowerShell 5.1 and every pwsh 7.x build.

param(
    [string]$OutFile = "$PSScriptRoot\..\network_status.txt"
)

if (-not $PSScriptRoot) {
    # Extremely defensive fallback - shouldn't be needed, but costs nothing
    $ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
    $OutFile = "$ScriptDir\..\network_status.txt"
}

$ErrorLogFile = Join-Path (Split-Path -Parent $OutFile) 'network_status_error.log'
$script:Errors = New-Object System.Collections.Generic.List[string]

# ---- EDIT THIS LIST to match the ports your server.py / flask / node apps use ----
$ports = @(3000, 4200, 5000, 5001, 5432, 8000, 8080, 8888, 9000)
# -----------------------------------------------------------------------------------

function Get-LocalIPv4Addresses {
    $result = New-Object System.Collections.Generic.List[string]
    try {
        $interfaces = [System.Net.NetworkInformation.NetworkInterface]::GetAllNetworkInterfaces()
        foreach ($nic in $interfaces) {
            if ($nic.OperationalStatus -ne [System.Net.NetworkInformation.OperationalStatus]::Up) { continue }
            if ($nic.NetworkInterfaceType -eq [System.Net.NetworkInformation.NetworkInterfaceType]::Loopback) { continue }
            $ipProps = $nic.GetIPProperties()
            foreach ($addrInfo in $ipProps.UnicastAddresses) {
                if ($addrInfo.Address.AddressFamily -eq [System.Net.Sockets.AddressFamily]::InterNetwork) {
                    $ipStr = $addrInfo.Address.IPAddressToString
                    if ($ipStr -notlike '169.254.*') {
                        $result.Add($ipStr)
                    }
                }
            }
        }
    } catch {
        $script:Errors.Add("Get-LocalIPv4Addresses failed: $($_.Exception.Message)")
    }

    # Extra fallback in case the NetworkInterface enumeration itself comes back empty
    if ($result.Count -eq 0) {
        try {
            $dnsIps = [System.Net.Dns]::GetHostAddresses([System.Net.Dns]::GetHostName()) |
                Where-Object { $_.AddressFamily -eq [System.Net.Sockets.AddressFamily]::InterNetwork } |
                ForEach-Object { $_.IPAddressToString }
            foreach ($ip in $dnsIps) { $result.Add($ip) }
        } catch {
            $script:Errors.Add("DNS fallback failed: $($_.Exception.Message)")
        }
    }

    return ($result | Select-Object -Unique)
}

function Test-PortOpen {
    param([int]$Port)
    try {
        $client = New-Object System.Net.Sockets.TcpClient
        $iar = $client.BeginConnect('127.0.0.1', $Port, $null, $null)
        $ok = $iar.AsyncWaitHandle.WaitOne(200, $false)
        $open = $ok -and $client.Connected
        $client.Close()
        return $open
    } catch {
        return $false
    }
}

function Get-ListeningProcessMap {
    # port (int) -> process name, built from a single netstat pass instead of
    # one Get-NetTCPConnection call per port
    $map = @{}
    try {
        $rows = & netstat.exe -ano -p TCP 2>$null | Select-Object -Skip 4
        foreach ($row in $rows) {
            $cols = ($row.Trim() -split '\s+')
            # Proto  LocalAddress  ForeignAddress  State  PID
            if ($cols.Count -ge 5 -and $cols[3] -eq 'LISTENING') {
                if ($cols[1] -match ':(\d+)$') {
                    $port = [int]$Matches[1]
                    if (-not $map.ContainsKey($port)) {
                        $procId = $cols[4]
                        try {
                            $proc = Get-Process -Id $procId -ErrorAction Stop
                            $map[$port] = $proc.ProcessName
                        } catch {
                            $map[$port] = "pid $procId"
                        }
                    }
                }
            }
        }
    } catch {
        $script:Errors.Add("Get-ListeningProcessMap failed: $($_.Exception.Message)")
    }
    return $map
}

$lines = New-Object System.Collections.Generic.List[string]

$ips = Get-LocalIPv4Addresses
$lines.Add("IPCOUNT=$($ips.Count)")
for ($i = 0; $i -lt $ips.Count; $i++) {
    $lines.Add("IP$($i)=$($ips[$i])")
}

$procMap = Get-ListeningProcessMap
foreach ($p in $ports) {
    $isOpen = Test-PortOpen -Port $p
    $status = if ($isOpen) { 'OPEN' } else { 'CLOSED' }
    $lines.Add("PORT_$p=$status")

    $procText = ''
    if ($isOpen -and $procMap.ContainsKey($p)) {
        $procText = " . $($procMap[$p])"
    }
    $lines.Add("PORT_${p}_PROC=$procText")
}

$lines.Add("LASTRUN=$(Get-Date -Format 'HH:mm:ss')")
$lines.Add("ERRORCOUNT=$($script:Errors.Count)")

try {
    $lines | Out-File -FilePath $OutFile -Encoding UTF8 -Force
} catch {
    # If we can't even write the main file, at least try to leave a trail
    $script:Errors.Add("Writing output file failed: $($_.Exception.Message)")
}

if ($script:Errors.Count -gt 0) {
    try {
        $header = "---- $(Get-Date) (PS $($PSVersionTable.PSVersion)) ----"
        @($header) + $script:Errors | Out-File -FilePath $ErrorLogFile -Encoding UTF8 -Append
    } catch {
        # nothing more we can do
    }
}
